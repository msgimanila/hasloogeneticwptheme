<?php
/**

 */
hasloo();