<?php
/**

 */
?></div><!-- end #inner -->
<?php
	hasloo_before_footer();
	hasloo_footer();
	hasloo_after_footer();
?>
</div><!-- end #wrap -->
<?php
	wp_footer(); // we need this for plugins
	hasloo_after();
?>
</body>
</html>