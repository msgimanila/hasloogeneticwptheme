HASLOO Genetic Framework for WordPress
http://www.hasloo.com

INSTALL
1. Upload the theme folder via FTP to your wp-content/themes/ directory.
2. Go to your WordPress dashboard and select Appearance.
3. Be sure to activate the Hasloo child theme, and not the Genesis parent theme.
4. Inside your WordPress dashboard, go to Hasloo > Theme Settings and configure them to your liking.

WIDGETS
Primary Sidebar - This is the primary sidebar if you are using the Content/Sidebar, Sidebar/Content, Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.
Secondary Sidebar - This is the secondary sidebar if you are using the Content/Sidebar/Sidebar, Sidebar/Sidebar/Content or Sidebar/Content/Sidebar Site Layout option.

INDEX.PHP FILE
This file in the Genetic theme framework controls archive, author, category, search and tag pages. If you wish to control them individually, you can create/use archive.php, author.php, category.php, search.php and tag.php files respectively.

SUPPORT
If you are looking for theme support, please visit http://www.hasloo.com/hasloogenetic.