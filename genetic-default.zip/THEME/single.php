<?php
/**

 *
 * This file handles posts, but only exists for the sake of
 * child theme forward compatibility.
 */
hasloo();