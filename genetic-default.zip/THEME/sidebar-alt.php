<?php
/**

 */
?><div id="sidebar-alt" class="widget-area">
<?php
	hasloo_before_sidebar_alt_widget_area();
	hasloo_sidebar_alt();
	hasloo_after_sidebar_alt_widget_area();
?>
</div>