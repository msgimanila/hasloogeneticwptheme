<?php
/**

 */
?><div id="sidebar" class="col-xs-6">
<?php
	hasloo_before_sidebar_widget_area();
	hasloo_sidebar();
	hasloo_after_sidebar_widget_area();
?>
</div>